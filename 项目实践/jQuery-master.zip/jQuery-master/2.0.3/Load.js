[
	'Core',
	'Sizzle',
	'Callbacks',
	'Deferred',
	'Support',
	'Data',
	'Queue',
	'Attr',
	'Event',
	'Dom',
	'Css',
	'Core2',
	'Ajax',
	'Animation'
].forEach(function(name) {
	document.write("<scr" + "ipt type='text/javascript' src='../src/" + name + ".js'></scr" + "ipt>");
})