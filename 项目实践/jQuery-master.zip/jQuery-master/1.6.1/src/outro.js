window.jQuery = window.$ = jQuery;
})(window);
